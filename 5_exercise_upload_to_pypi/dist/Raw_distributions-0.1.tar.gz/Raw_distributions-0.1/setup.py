from setuptools import setup

setup(name='Raw_distributions',
      version='0.1',
      description='Gaussian distributions',
      author= 'Rawan Galal',
      packages=['Raw_distributions'],
      zip_safe=False)
