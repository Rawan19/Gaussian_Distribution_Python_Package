from setuptools import setup

setup(name='RG_distributions',
      version='0.1',
      description='Gaussian distributions',
      author= 'Rawan Galal',
      packages=['RG_distributions'],
      zip_safe=False)
